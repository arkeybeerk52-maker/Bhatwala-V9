# Remaining production polish

Already scaffolded:
- Home / Hindi UI
- Authentication + password reset
- Permanent user ID assignment through Cloud Function
- News/events/collection feeds
- Search
- Post composer + moderation status
- Media upload + moderation status
- User profile + My Posts
- Admin dashboard + moderation
- Admin user block/unblock
- Complaints/suggestions + reports
- FCM token registration + moderation notification Functions

Recommended final work in the next builder:
1. Detail pages for each content type.
2. Comments, likes, saves, shares.
3. Emergency contact one-tap calling.
4. Place maps/directions.
5. Notification inbox + foreground/background Android handling.
6. Profile photo/phone editing.
7. Admin create/edit forms and richer moderation UI.
8. Gallery thumbnails/video playback.
9. Offline/error/empty states and accessibility.
10. Automated tests, release signing, APK/AAB and Play Store preparation.
