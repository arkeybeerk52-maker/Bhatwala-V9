# Bhatwala / भाटवाला — Real Flutter + Firebase starter

This is a continuation-ready Android app project, not a static mockup. It contains the Hindi-first Bhatwala home UI, Firebase Authentication, Firestore models/services, moderation flow, media upload flow, search, user profile, My Posts, admin dashboard/user management, complaints/reports, FCM token registration, and Firebase Cloud Functions scaffolding.

## Important
- Do NOT put admin passwords in source code.
- Primary admin email: `raajchoudhary.rk52@gmail.com`
- Firebase project configuration (`google-services.json`, `GoogleService-Info.plist`) is intentionally not included.
- The next builder should preserve this project and finish production wiring rather than recreate the app.

## Build sequence
1. Create/connect the Firebase project.
2. Enable Email/Password Authentication.
3. Add Android Firebase config and run `flutterfire configure` if needed.
4. Deploy `firestore.rules`, `firestore.indexes.json`, `storage.rules`.
5. In `functions/`, install dependencies and deploy Cloud Functions.
6. Create/mark the primary admin user using a secure server/admin process. Do not hard-code a password.
7. Add Android app signing/package ID and build APK/AAB.

## Implemented in this starter
- Auth: register, login, password reset.
- Permanent user-ID assignment via Cloud Function: `BHT-000001`, `BHT-000002`, ...
- User profile, My Posts, logout.
- Home UI matching the supplied visual direction.
- Search across approved community content.
- Post submission with pending moderation.
- Photo/video picker + Firebase Storage upload + pending media record.
- Admin dashboard, moderation and user block/unblock.
- Complaints/suggestions and reports.
- FCM token registration and server notification functions for moderation events.
- Security rules with explicit collection access and no broad public wildcard read rule.

## Still worth finishing in the next builder
- Rich detail pages, comments/likes/saves/shares.
- Emergency one-tap calling and place map/directions.
- Full admin content creation/editing screens.
- Notification inbox UI and Android notification handling UI.
- Better image/video gallery thumbnails and playback.
- Profile photo/phone editing.
- Offline cache, analytics/crash reporting, accessibility and full automated tests.

## V6 Firebase-ready additions
The project now includes the social interaction service layer (comments, likes, saves, shares), notification stream UI, profile editing, emergency calling screen, detail-screen foundation, Firestore rules for social collections, and a continuation/deployment checklist in `NEXT_BUILDER_PROMPT.md`.

## V8 handoff
See `V8_COMPLETION.md` and `NEXT_BUILDER_PROMPT.md`. The project is intended to be continued, not rebuilt.
