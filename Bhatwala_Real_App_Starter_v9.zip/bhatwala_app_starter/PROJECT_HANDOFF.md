# BHATWALA — MASTER HANDOFF

Continue the existing project. Do not rebuild from zero.

## Product
Hindi-first real Android community app for Bhatwala village. Branding: `भाटवाला` / `BHATWALA`. No builder branding, watermark or “Made with …” text.

## Visual source of truth
Use the user's supplied Bhatwala screenshot as the visual reference. Preserve the green rounded header, white search field, yellow village-notice card, rounded 2-column service cards and bottom navigation.

## Core modules already scaffolded
Authentication; user profile; permanent BHT user ID; home/services; Firestore approved-content feeds; post composer; moderation; admin dashboard; admin user blocking; complaints/suggestions; reports; media picker/upload; search; FCM token registration; Cloud Functions for sequential user IDs and moderation notifications.

## Admin
Primary admin email: `raajchoudhary.rk52@gmail.com`. Password must be created securely in Firebase Authentication and never committed to source. Server rules enforce admin privileges; UI hiding is not the security boundary.

## Data collections
`users`, `posts`, `news`, `businesses`, `jobs`, `events`, `media`, `complaints`, `reports`, `places`, `farmer_info`, `emergency_contacts`, `notifications`, `counters`.

## Moderation
User-created posts/media/business/job records are `pending` until admin approval. Approved content is public. Users can see their own pending/rejected content. Admin can approve/reject/hide/delete.

## Security notes
The rules intentionally avoid a broad `match /{col}/{id} { allow read: true; }` because that would expose private collections. User self-update cannot change `role`, `blocked`, `uid`, or permanent `userId`. Admin moderation is protected by Firestore rules.

## Firebase setup
Read `FIREBASE_SETUP.md`. Add the real Firebase Android configuration in the next environment. Deploy Firestore rules/indexes/storage rules and Functions.

## Final production work
Add rich detail pages, comments/likes/saves/shares, emergency calling, maps/directions, notification inbox, profile editing, polished gallery, offline handling, analytics/crash reporting, tests, app signing and APK/AAB build.
