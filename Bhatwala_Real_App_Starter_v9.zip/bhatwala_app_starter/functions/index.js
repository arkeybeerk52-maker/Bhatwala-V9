const { onDocumentCreated, onDocumentUpdated } = require('firebase-functions/v2/firestore');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const { getMessaging } = require('firebase-admin/messaging');
initializeApp();
const db = getFirestore();

exports.assignPermanentUserId = onDocumentCreated('users/{uid}', async (event) => {
  const uid = event.params.uid;
  const ref = db.collection('users').doc(uid);
  const counter = db.collection('counters').doc('users');
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists || snap.data().userId !== 'BHT-PENDING') return;
    const c = await tx.get(counter);
    const next = (c.exists ? Number(c.data().next || 1) : 1);
    const userId = `BHT-${String(next).padStart(6, '0')}`;
    tx.set(counter, {next: next + 1}, {merge:true});
    tx.update(ref, {userId, userIdAssignedAt: FieldValue.serverTimestamp()});
  });
});

async function tokensFor(uid){
  const snap=await db.collection('users').doc(uid).collection('devices').get();
  return snap.docs.map(d=>d.id).filter(Boolean);
}
async function sendToUser(uid,title,body,data={}){
  const tokens=await tokensFor(uid); if(!tokens.length)return;
  await getMessaging().sendEachForMulticast({tokens,notification:{title,body},data:Object.fromEntries(Object.entries(data).map(([k,v])=>[k,String(v)]))});
}
async function addNotification(uid,title,body,data={}){
  await db.collection('notifications').add({userUid:uid,title,body,data,read:false,createdAt:FieldValue.serverTimestamp()});
  await sendToUser(uid,title,body,data);
}

exports.notifyNewPendingPost = onDocumentCreated('posts/{postId}', async (event) => {
  const post=event.data?.data(); if(!post || post.status!=='pending')return;
  const users=await db.collection('users').get();
  for(const a of users.docs){ const d=a.data(); if(d.role==='admin' || d.email==='raajchoudhary.rk52@gmail.com') await addNotification(a.id,'नई पोस्ट समीक्षा के लिए',post.title||'नई पोस्ट',{type:'admin_review',postId:event.params.postId}); }
});

exports.notifyPostModeration = onDocumentUpdated('posts/{postId}', async (event) => {
  const before=event.data.before.data(), after=event.data.after.data();
  if(!before||!after||before.status===after.status||!after.authorUid)return;
  if(!['approved','rejected','hidden'].includes(after.status))return;
  const body=after.status==='approved'?'आपकी पोस्ट स्वीकृत हो गई है।':after.status==='rejected'?'आपकी पोस्ट अस्वीकृत हुई है।':'आपकी पोस्ट छिपा दी गई है।';
  await addNotification(after.authorUid,'भाटवाला पोस्ट अपडेट',body,{type:'post_status',postId:event.params.postId,status:after.status});
});

exports.notifyComplaintStatus = onDocumentUpdated('complaints/{id}', async(event)=>{
  const before=event.data.before.data(), after=event.data.after.data();
  if(!before||!after||before.status===after.status||!after.userUid)return;
  await addNotification(after.userUid,'शिकायत/सुझाव अपडेट',`आपकी ${after.type==='suggestion'?'सुझाव':'शिकायत'} की स्थिति: ${after.status}`,{type:'complaint_status',complaintId:event.params.id,status:after.status});
});
