import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'services/firebase_service.dart';
import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';
import 'screens/blocked_screen.dart';

@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try { await Firebase.initializeApp(); FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler); } catch (_) {}
  runApp(const BhatwalaApp());
}

class BhatwalaApp extends StatelessWidget {
  const BhatwalaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'भाटवाला',
    theme: ThemeData(useMaterial3: true, scaffoldBackgroundColor: const Color(0xFFF7F8F6), colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF18864B))),
    home: const AuthGate(),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder(
    stream: FirebaseService().auth.authStateChanges(),
    builder: (context, snap) => snap.connectionState == ConnectionState.waiting
      ? const Scaffold(body: Center(child: CircularProgressIndicator()))
      : snap.data == null ? const AuthScreen() : FutureBuilder<bool>(future: FirebaseService().isBlocked(), builder: (context,b) => b.data == true ? const BlockedScreen() : const HomeScreen()),
  );
}
