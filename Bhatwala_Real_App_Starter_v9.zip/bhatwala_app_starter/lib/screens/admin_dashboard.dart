import 'package:flutter/material.dart';
import '../services/firebase_service.dart';
import 'admin_users_screen.dart';

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});

  @override Widget build(BuildContext context) {
    final items = [
      ('👥','उपयोगकर्ता','users'),
      ('📰','खबरें','news'),
      ('📝','लंबित पोस्ट','posts'),
      ('🏪','व्यवसाय','businesses'),
      ('💼','रोजगार','jobs'),
      ('🎉','कार्यक्रम','events'),
      ('📸','फोटो/वीडियो','media'),
      ('📋','शिकायतें','complaints'),
      ('⚠️','रिपोर्ट','reports'),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('भाटवाला Admin Panel')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('एडमिन डैशबोर्ड',
            style: TextStyle(fontSize:26,fontWeight:FontWeight.w900)),
          const SizedBox(height:6),
          const Text('सिर्फ अधिकृत Admin के लिए'),
          const SizedBox(height:18),
          GridView.builder(
            shrinkWrap:true, physics:const NeverScrollableScrollPhysics(),
            itemCount:items.length,
            gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount:2,crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:1.35),
            itemBuilder:(c,i){
              final x=items[i];
              return Card(
                child: InkWell(
                  onTap: ()=>Navigator.push(context, MaterialPageRoute(
                    builder:(_)=>x.$3=='users' ? const AdminUsersScreen() : AdminCollectionScreen(title:x.$2, collection:x.$3))),
                  child: Padding(padding:const EdgeInsets.all(16),
                    child:Column(crossAxisAlignment:CrossAxisAlignment.start,
                      mainAxisAlignment:MainAxisAlignment.center,
                      children:[Text(x.$1,style:const TextStyle(fontSize:28)),
                        const SizedBox(height:8),Text(x.$2,
                          style:const TextStyle(fontWeight:FontWeight.w800))])),
                ));
            }),
        ],
      ),
    );
  }
}

class AdminCollectionScreen extends StatelessWidget {
  final String title, collection;
  const AdminCollectionScreen({super.key,required this.title,required this.collection});

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title:Text(title)),
    body: StreamBuilder(
      stream: FirebaseService().collectionStream(collection),
      builder:(context,snapshot){
        if(snapshot.connectionState==ConnectionState.waiting) {
          return const Center(child:CircularProgressIndicator());
        }
        if(snapshot.hasError) return Center(child:Text('डेटा लोड नहीं हुआ: ${snapshot.error}'));
        final docs = snapshot.data?.docs ?? [];
        if(docs.isEmpty) return const Center(child:Text('अभी कोई रिकॉर्ड नहीं है।'));
        return ListView.builder(
          itemCount:docs.length,
          itemBuilder:(c,i){
            final data=docs[i].data() as Map<String,dynamic>;
            return ListTile(
              title:Text((data['title'] ?? data['name'] ?? 'रिकॉर्ड').toString()),
              subtitle:Text('स्थिति: ${(data['status'] ?? '—').toString()}'),
              trailing:PopupMenuButton<String>(
                onSelected:(action)=>FirebaseService().adminModerate(collection, docs[i].id, action),
                itemBuilder:(_)=>const [
                  PopupMenuItem(value:'approved',child:Text('स्वीकृत')),
                  PopupMenuItem(value:'rejected',child:Text('अस्वीकृत')),
                  PopupMenuItem(value:'hidden',child:Text('छिपाएँ')),
                  PopupMenuItem(value:'delete',child:Text('डिलीट')),
                ]),
            );
          });
      }),
  );
}
