import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/firebase_service.dart';

class MediaUploadScreen extends StatefulWidget { const MediaUploadScreen({super.key}); @override State<MediaUploadScreen> createState()=>_MediaUploadScreenState(); }
class _MediaUploadScreenState extends State<MediaUploadScreen>{
  final picker=ImagePicker(); XFile? file; bool video=false,busy=false;
  Future<void> pick(bool isVideo) async { final x=isVideo?await picker.pickVideo(source:ImageSource.gallery):await picker.pickImage(source:ImageSource.gallery,imageQuality:85); if(x!=null)setState(() { file=x; video=isVideo; }); }
  Future<void> upload() async { if(file==null)return; setState(()=>busy=true); try{await FirebaseService().uploadMedia(file!,video:video);if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('मीडिया समीक्षा के लिए भेज दिया गया।')));Navigator.pop(context);}}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('अपलोड नहीं हुआ: $e')));}finally{if(mounted)setState(()=>busy=false);} }
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('फोटो / वीडियो डालें')),body:Padding(padding:const EdgeInsets.all(20),child:Column(children:[Row(children:[Expanded(child:OutlinedButton.icon(onPressed:()=>pick(false),icon:const Icon(Icons.photo),label:const Text('फोटो चुनें'))),const SizedBox(width:10),Expanded(child:OutlinedButton.icon(onPressed:()=>pick(true),icon:const Icon(Icons.videocam),label:const Text('वीडियो चुनें')))]),const SizedBox(height:20),if(file!=null)ListTile(leading:Icon(video?Icons.videocam:Icons.image),title:Text(file!.name),subtitle:const Text('चुनी गई फ़ाइल')),const Spacer(),SizedBox(width:double.infinity,child:FilledButton(onPressed:file==null||busy?null:upload,child:Text(busy?'अपलोड हो रहा है...':'अपलोड करें')))]));
}
