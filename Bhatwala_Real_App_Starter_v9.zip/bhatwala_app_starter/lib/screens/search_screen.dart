import 'package:flutter/material.dart';
import '../services/firebase_service.dart';
import 'post_detail_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final q = TextEditingController();
  bool loading = false;
  List<Map<String,dynamic>> results = [];

  Future<void> search() async {
    final term = q.text.trim();
    if (term.isEmpty) return;
    setState(() => loading = true);
    try {
      final data = await FirebaseService().searchAll(term);
      if (mounted) setState(() => results = data);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('खोज नहीं हो सकी: $e')));
    } finally { if (mounted) setState(() => loading = false); }
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('गाँव में खोजें')),
    body: Column(children: [
      Padding(padding: const EdgeInsets.all(16), child: TextField(
        controller: q, textInputAction: TextInputAction.search, onSubmitted: (_) => search(),
        decoration: InputDecoration(hintText: 'खबर, दुकान, काम, कार्यक्रम...', prefixIcon: const Icon(Icons.search), suffixIcon: IconButton(onPressed: search, icon: const Icon(Icons.arrow_forward)), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))),
      )),
      if (loading) const LinearProgressIndicator(),
      Expanded(child: results.isEmpty && !loading ? const Center(child: Text('खोजने के लिए ऊपर लिखें।')) : ListView.separated(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24), itemCount: results.length, separatorBuilder: (_,__) => const SizedBox(height: 8),
        itemBuilder: (_, i) { final r = results[i]; return Card(child: ListTile(leading: Text(r['icon'] ?? '📄', style: const TextStyle(fontSize: 24)), title: Text('${r['title'] ?? r['name'] ?? 'जानकारी'}'), subtitle: Text('${r['description'] ?? r['text'] ?? r['address'] ?? ''}'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PostDetailScreen(collection: '${r['collection']}', id: '${r['id']}', title: '${r['title'] ?? r['name'] ?? 'जानकारी'}')))); },
      )),
    ]),
  );
}
