import 'package:flutter/material.dart';
import '../services/firebase_service.dart';

class ReportScreen extends StatefulWidget {
  final String collection; final String documentId;
  const ReportScreen({super.key, required this.collection, required this.documentId});
  @override State<ReportScreen> createState() => _ReportScreenState();
}
class _ReportScreenState extends State<ReportScreen> {
  final reason = TextEditingController(); bool busy=false;
  Future<void> send() async { if(reason.text.trim().isEmpty)return; setState(()=>busy=true); try { await FirebaseService().report(collection:widget.collection, documentId:widget.documentId, reason:reason.text.trim()); if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('रिपोर्ट भेज दी गई।')));Navigator.pop(context);}} catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));} finally{if(mounted)setState(()=>busy=false);} }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('रिपोर्ट करें')),body:Padding(padding:const EdgeInsets.all(20),child:Column(children:[TextField(controller:reason,maxLines:5,decoration:const InputDecoration(border:OutlineInputBorder(),labelText:'कारण',hintText:'किस वजह से रिपोर्ट कर रहे हैं?')),const SizedBox(height:16),SizedBox(width:double.infinity,child:FilledButton(onPressed:busy?null:send,child:Text(busy?'भेज रहे हैं...':'रिपोर्ट भेजें')))])));
}
