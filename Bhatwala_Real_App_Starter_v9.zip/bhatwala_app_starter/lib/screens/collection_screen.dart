import 'package:flutter/material.dart';
import '../services/firebase_service.dart';
import 'post_detail_screen.dart';

class CollectionScreen extends StatelessWidget {
  final String title, collection, emptyText;
  const CollectionScreen({super.key,required this.title,required this.collection,this.emptyText='अभी कोई जानकारी उपलब्ध नहीं है।'});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(title)),body:StreamBuilder(stream:FirebaseService().approved(collection),builder:(c,s){if(s.hasError)return Center(child:Text('डेटा लोड नहीं हो सका।'));if(!s.hasData)return const Center(child:CircularProgressIndicator());final docs=s.data!.docs;if(docs.isEmpty)return Center(child:Text(emptyText));return ListView.separated(padding:const EdgeInsets.all(16),itemCount:docs.length,separatorBuilder:(_,__)=>const SizedBox(height:10),itemBuilder:(_,i){final d=docs[i].data();final id=docs[i].id;final heading='${d['title']??d['name']??'जानकारी'}';final image=d['imageUrl']??d['photoUrl'];return Card(clipBehavior:Clip.antiAlias,child:InkWell(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>PostDetailScreen(collection:collection,id:id,title:heading))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[if(image is String && image.isNotEmpty)Image.network(image,height:150,width:double.infinity,fit:BoxFit.cover,errorBuilder:(_,__,___)=>const SizedBox.shrink()),ListTile(title:Text(heading),subtitle:Text('${d['description']??d['text']??d['address']??''}',maxLines:3,overflow:TextOverflow.ellipsis),trailing:const Icon(Icons.chevron_right))])));});}));
}
