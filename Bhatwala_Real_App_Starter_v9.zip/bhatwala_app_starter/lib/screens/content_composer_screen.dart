import 'package:flutter/material.dart';
import '../services/firebase_service.dart';

class ContentComposerScreen extends StatefulWidget {
  const ContentComposerScreen({super.key});
  @override State<ContentComposerScreen> createState()=>_ContentComposerScreenState();
}
class _ContentComposerScreenState extends State<ContentComposerScreen>{
  final title=TextEditingController(), description=TextEditingController(), phone=TextEditingController(), address=TextEditingController();
  String type='businesses'; bool busy=false;
  final types=const {'businesses':'दुकान / व्यवसाय','jobs':'काम / रोजगार','events':'कार्यक्रम','news':'गाँव की खबर','farmer_info':'किसान जानकारी','places':'जरूरी स्थान'};
  Future<void> submit() async {
    if(title.text.trim().isEmpty || description.text.trim().isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('शीर्षक और विवरण भरें')));return;}
    setState(()=>busy=true);
    try{await FirebaseService().submitListing(collection:type,title:title.text,description:description.text,phone:phone.text,address:address.text);if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('जानकारी समीक्षा के लिए भेज दी गई है।')));Navigator.pop(context);}}
    catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('सेव नहीं हुआ: $e')));} finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('नई जानकारी डालें')),body:ListView(padding:const EdgeInsets.all(18),children:[DropdownButtonFormField<String>(value:type,items:types.entries.map((e)=>DropdownMenuItem(value:e.key,child:Text(e.value))).toList(),onChanged:(v)=>setState(()=>type=v!),decoration:const InputDecoration(labelText:'श्रेणी',border:OutlineInputBorder())),const SizedBox(height:12),TextField(controller:title,decoration:const InputDecoration(labelText:'शीर्षक / नाम',border:OutlineInputBorder())),const SizedBox(height:12),TextField(controller:description,maxLines:5,decoration:const InputDecoration(labelText:'विवरण',border:OutlineInputBorder())),const SizedBox(height:12),TextField(controller:phone,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'फोन (वैकल्पिक)',border:OutlineInputBorder())),const SizedBox(height:12),TextField(controller:address,decoration:const InputDecoration(labelText:'पता / स्थान (वैकल्पिक)',border:OutlineInputBorder())),const SizedBox(height:20),FilledButton(onPressed:busy?null:submit,child:Text(busy?'भेज रहे हैं...':'समीक्षा के लिए भेजें')),const SizedBox(height:8),const Text('आपकी जानकारी पहले Admin की समीक्षा में जाएगी।',style:TextStyle(color:Colors.black54))]));
}
