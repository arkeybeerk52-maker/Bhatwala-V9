import 'package:flutter/material.dart';
import '../services/firebase_service.dart';

class AdminUsersScreen extends StatelessWidget {
  const AdminUsersScreen({super.key});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('यूज़र मैनेजमेंट')),body:StreamBuilder(stream:FirebaseService().adminCollection('users'),builder:(c,s){
    if(s.hasError)return Center(child:Text('लोड नहीं हुआ: ${s.error}')); if(!s.hasData)return const Center(child:CircularProgressIndicator()); final docs=s.data!.docs;
    if(docs.isEmpty)return const Center(child:Text('कोई यूज़र नहीं है।'));
    return ListView.separated(padding:const EdgeInsets.all(12),itemCount:docs.length,separatorBuilder:(_,__)=>const Divider(),itemBuilder:(_,i){final d=docs[i].data();final blocked=d['blocked']==true;return ListTile(leading:CircleAvatar(child:Text('${d['name']??'U'}'.substring(0,1))),title:Text('${d['name']??'यूज़र'}'),subtitle:Text('${d['userId']??''}\n${d['email']??''}'),isThreeLine:true,trailing:PopupMenuButton<String>(onSelected:(a)=>FirebaseService().setUserBlocked(docs[i].id,a=='block'),itemBuilder:(_)=>[PopupMenuItem(value:blocked?'unblock':'block',child:Text(blocked?'अनब्लॉक करें':'ब्लॉक करें'))]));});
  }));
}
