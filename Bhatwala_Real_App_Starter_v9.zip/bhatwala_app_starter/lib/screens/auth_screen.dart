import 'package:flutter/material.dart';
import '../services/firebase_service.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override State<AuthScreen> createState() => _AuthScreenState();
}
class _AuthScreenState extends State<AuthScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  final name = TextEditingController();
  bool register = false, loading = false;
  final service = FirebaseService();

  Future<void> submit() async {
    setState(() => loading = true);
    try {
      if (register) {
        await service.registerUser(name.text.trim(), email.text.trim(), password.text);
      } else {
        await service.login(email.text.trim(), password.text);
      }
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('कुछ समस्या हुई: $e')));
    } finally { if (mounted) setState(() => loading = false); }
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(register ? 'रजिस्टर करें' : 'लॉगिन')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      if (register) TextField(controller: name, decoration: const InputDecoration(labelText: 'नाम')),
      TextField(controller: email, decoration: const InputDecoration(labelText: 'ईमेल')),
      TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'पासवर्ड')),
      const SizedBox(height: 20),
      FilledButton(onPressed: loading ? null : submit,
        child: Text(loading ? 'कृपया प्रतीक्षा करें…' : (register ? 'रजिस्टर' : 'लॉगिन'))),
      TextButton(onPressed: () => setState(() => register = !register),
        child: Text(register ? 'पहले से अकाउंट है? लॉगिन' : 'नया अकाउंट बनाएँ')),
      if (!register) TextButton(onPressed: () async { if(email.text.trim().isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('पहले ईमेल डालें'))); return; } try { await service.resetPassword(email.text); if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('पासवर्ड रीसेट लिंक ईमेल पर भेज दिया गया।'))); } catch(e) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('रीसेट नहीं हुआ: $e'))); } }, child: const Text('पासवर्ड भूल गए?')),
    ]),
  );
}
