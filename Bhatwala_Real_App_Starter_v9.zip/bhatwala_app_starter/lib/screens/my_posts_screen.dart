import 'package:flutter/material.dart';
import '../services/firebase_service.dart';

class MyPostsScreen extends StatelessWidget {
  const MyPostsScreen({super.key});
  Color _statusColor(String s) => s == 'approved' ? Colors.green : s == 'rejected' ? Colors.red : s == 'hidden' ? Colors.grey : Colors.orange;
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('मेरी पोस्ट')),
    body: StreamBuilder(stream: FirebaseService().myPosts(), builder: (c,s) {
      if (s.hasError) return Center(child: Text('लोड नहीं हुआ: ${s.error}'));
      if (!s.hasData) return const Center(child: CircularProgressIndicator());
      final docs = s.data!.docs;
      if (docs.isEmpty) return const Center(child: Text('आपने अभी कोई पोस्ट नहीं डाली।'));
      return ListView.separated(padding: const EdgeInsets.all(16), itemCount: docs.length, separatorBuilder: (_,__) => const SizedBox(height: 10), itemBuilder: (_,i) {
        final d = docs[i].data(); final status = '${d['status'] ?? 'pending'}';
        return Card(child: ListTile(title: Text('${d['title'] ?? 'बिना शीर्षक'}'), subtitle: Text('${d['description'] ?? ''}'), trailing: Chip(label: Text(status), backgroundColor: _statusColor(status).withOpacity(.12))));
      });
    }),
  );
}
