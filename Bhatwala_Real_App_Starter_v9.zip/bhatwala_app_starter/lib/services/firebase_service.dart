import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:image_picker/image_picker.dart';

class FirebaseService {
  final db = FirebaseFirestore.instance;
  final auth = FirebaseAuth.instance;
  final storage = FirebaseStorage.instance;
  final messaging = FirebaseMessaging.instance;

  Stream<DocumentSnapshot<Map<String,dynamic>>> myProfile() => db.collection('users').doc(auth.currentUser!.uid).snapshots();
  Future<bool> isBlocked() async { final u=auth.currentUser; if(u==null)return false; final d=await db.collection('users').doc(u.uid).get(); return d.data()?['blocked']==true; }

  Future<void> registerUser(String name, String email, String password) async {
    if (name.trim().length < 2) throw Exception('कृपया सही नाम डालें');
    final c = await auth.createUserWithEmailAndPassword(email: email.trim(), password: password);
    await db.collection('users').doc(c.user!.uid).set({'uid':c.user!.uid,'userId':'BHT-PENDING','name':name.trim(),'email':email.trim(),'role':'user','blocked':false,'createdAt':FieldValue.serverTimestamp()});
    await saveFcmToken();
  }
  Future<void> login(String email,String password) async { await auth.signInWithEmailAndPassword(email:email.trim(),password:password); await saveFcmToken(); }
  Future<void> logout()=>auth.signOut();
  Future<void> resetPassword(String email) => auth.sendPasswordResetEmail(email: email.trim());

  Future<void> submitPost({required String title,required String description,required String category, String? imageUrl}) async {
    final u=auth.currentUser; if(u==null) throw Exception('कृपया पहले लॉगिन करें');
    final p=await db.collection('users').doc(u.uid).get(); final d=p.data()??{};
    await db.collection('posts').add({'title':title.trim(),'description':description.trim(),'category':category,'authorUid':u.uid,'authorName':d['name']??u.email??'User','authorUserId':d['userId']??'','status':'pending','likesCount':0,'commentsCount':0,'sharesCount':0,'imageUrl':imageUrl,'createdAt':FieldValue.serverTimestamp()});
  }

  Future<String> uploadFile(File file,String folder) async {
    final u=auth.currentUser; if(u==null) throw Exception('Login required');
    final name='${DateTime.now().millisecondsSinceEpoch}_${file.path.split('/').last}';
    final ref=storage.ref('$folder/${u.uid}/$name');
    await ref.putFile(file); return ref.getDownloadURL();
  }

  Future<String> uploadProfilePhoto(XFile x) async {
    final u=auth.currentUser; if(u==null) throw Exception('कृपया पहले लॉगिन करें');
    final url=await uploadFile(File(x.path), 'users');
    await db.collection('users').doc(u.uid).update({'photoUrl':url,'updatedAt':FieldValue.serverTimestamp()});
    return url;
  }

  Future<void> uploadMedia(XFile x,{required bool video}) async {
    final u=auth.currentUser; if(u==null) throw Exception('कृपया पहले लॉगिन करें');
    final url=await uploadFile(File(x.path), video?'videos':'photos');
    final profile=await db.collection('users').doc(u.uid).get();
    await db.collection('media').add({'type':video?'video':'photo','url':url,'fileName':x.name,'authorUid':u.uid,'authorName':profile.data()?['name']??'User','status':'pending','createdAt':FieldValue.serverTimestamp()});
  }

  Stream<QuerySnapshot<Map<String,dynamic>>> approved(String collection) => db.collection(collection).where('status',isEqualTo:'approved').orderBy('createdAt',descending:true).snapshots();
  Stream<QuerySnapshot<Map<String,dynamic>>> myPosts() => db.collection('posts').where('authorUid',isEqualTo:auth.currentUser!.uid).orderBy('createdAt',descending:true).snapshots();
  Stream<QuerySnapshot<Map<String,dynamic>>> adminCollection(String collection) => db.collection(collection).orderBy('createdAt',descending:true).snapshots();
  Stream<QuerySnapshot<Map<String,dynamic>>> adminUsers() => db.collection('users').orderBy('createdAt', descending: true).snapshots();
  Stream<QuerySnapshot<Map<String,dynamic>>> collectionStream(String collection) => db.collection(collection).orderBy('createdAt', descending: true).snapshots();

  Future<void> setUserBlocked(String uid, bool blocked) async {
    if (!await isAdmin()) throw Exception('Admin access required');
    await db.collection('users').doc(uid).update({'blocked':blocked,'updatedAt':FieldValue.serverTimestamp()});
  }

  Future<void> adminModerate(String collection,String id,String action) async {
    if (!await isAdmin()) throw Exception('Admin access required');
    if(action=='delete'){await db.collection(collection).doc(id).delete();return;}
    await db.collection(collection).doc(id).update({'status':action,'moderatedAt':FieldValue.serverTimestamp(),'moderatedBy':auth.currentUser?.uid});
  }
  Future<void> moderate(String collection,String id,String action) => adminModerate(collection,id,action);
  Future<bool> isAdmin() async {
    final u=auth.currentUser; if(u==null)return false;
    final d=await db.collection('users').doc(u.uid).get(); return d.data()?['role']=='admin' || u.email=='raajchoudhary.rk52@gmail.com';
  }
  Future<void> submitListing({required String collection, required String title, required String description, String? phone, String? address, String? category}) async {
    const allowed = {'news','events','businesses','jobs','places','farmer_info'};
    if (!allowed.contains(collection)) throw Exception('यह श्रेणी उपलब्ध नहीं है');
    final u=auth.currentUser; if(u==null) throw Exception('कृपया पहले लॉगिन करें');
    final p=await db.collection('users').doc(u.uid).get(); final d=p.data()??{};
    await db.collection(collection).add({
      'title': title.trim(), 'description': description.trim(), 'phone': phone?.trim(), 'address': address?.trim(),
      'category': category?.trim(), 'ownerUid': u.uid, 'authorUid': u.uid,
      'authorName': d['name']??u.email??'User', 'status':'pending',
      'likesCount':0, 'commentsCount':0, 'sharesCount':0, 'createdAt':FieldValue.serverTimestamp()
    });
  }

  Future<void> submitComplaint(String text,{bool suggestion=false}) async {
    final u=auth.currentUser; if(u==null)throw Exception('कृपया पहले लॉगिन करें');
    await db.collection('complaints').add({'userUid':u.uid,'type':suggestion?'suggestion':'complaint','text':text.trim(),'status':'pending','createdAt':FieldValue.serverTimestamp()});
  }
  Future<void> report({required String collection,required String documentId,required String reason}) async {
    final u=auth.currentUser; if(u==null)throw Exception('कृपया पहले लॉगिन करें');
    await db.collection('reports').add({'reporterUid':u.uid,'collection':collection,'documentId':documentId,'reason':reason,'status':'pending','createdAt':FieldValue.serverTimestamp()});
  }
  Future<List<Map<String,dynamic>>> searchAll(String term) async {
    final q=term.trim(); final List<Map<String,dynamic>> out=[];
    const cols=['news','posts','businesses','jobs','events','places','farmer_info'];
    for(final c in cols){
      try{
        final snap=await db.collection(c).where('status',isEqualTo:'approved').where('title',isGreaterThanOrEqualTo:q).where('title',isLessThanOrEqualTo:'$q\uf8ff').limit(8).get();
        for(final d in snap.docs){final x=d.data();out.add({...x,'icon':_icon(c),'collection':c,'id':d.id});}
      }catch(_){ }
    }
    return out;
  }
  String _icon(String c)=>switch(c){'news'=>'📰','posts'=>'📝','businesses'=>'🏪','jobs'=>'💼','events'=>'🎉','places'=>'📍','farmer_info'=>'🌾',_=>'📄'};

  Stream<DocumentSnapshot<Map<String,dynamic>>> document(String collection,String id) => db.collection(collection).doc(id).snapshots();
  Stream<QuerySnapshot<Map<String,dynamic>>> publicCollection(String collection) => db.collection(collection).snapshots();
  Stream<QuerySnapshot<Map<String,dynamic>>> comments(String collection,String id) => db.collection('comments').where('collection',isEqualTo:collection).where('documentId',isEqualTo:id).orderBy('createdAt',descending:true).snapshots();
  Stream<QuerySnapshot<Map<String,dynamic>>> notifications() {
    final u=auth.currentUser; if(u==null) return const Stream.empty();
    return db.collection('notifications').where('userUid',isEqualTo:u.uid).orderBy('createdAt',descending:true).limit(50).snapshots();
  }
  Future<void> addComment(String collection,String id,String text) async {
    final u=auth.currentUser; if(u==null) throw Exception('कृपया पहले लॉगिन करें');
    final p=await db.collection('users').doc(u.uid).get();
    final commentRef=db.collection('comments').doc();
    final contentRef=db.collection(collection).doc(id);
    await db.runTransaction((tx) async {
      final content=await tx.get(contentRef);
      if(!content.exists) throw Exception('यह सामग्री उपलब्ध नहीं है');
      tx.set(commentRef, {'collection':collection,'documentId':id,'authorUid':u.uid,'authorName':p.data()?['name']??u.email??'User','text':text.trim(),'createdAt':FieldValue.serverTimestamp()});
      final current=((content.data()?['commentsCount'] ?? 0) as num).toInt();
      tx.update(contentRef, {'commentsCount':current+1});
    });
  }
  Future<void> toggleLike(String collection,String id) async {
    final u=auth.currentUser; if(u==null) throw Exception('कृपया पहले लॉगिन करें');
    final likeRef=db.collection('likes').doc('${collection}_$id').collection('users').doc(u.uid);
    final contentRef=db.collection(collection).doc(id);
    await db.runTransaction((tx) async {
      final snap=await tx.get(likeRef);
      final content=await tx.get(contentRef);
      if(!content.exists) throw Exception('यह सामग्री उपलब्ध नहीं है');
      final current=((content.data()?['likesCount'] ?? 0) as num).toInt();
      if(snap.exists){ tx.delete(likeRef); tx.update(contentRef, {'likesCount': current > 0 ? current-1 : 0}); }
      else { tx.set(likeRef, {'uid':u.uid,'createdAt':FieldValue.serverTimestamp()}); tx.update(contentRef, {'likesCount': current+1}); }
    });
  }
  Future<void> toggleSave(String collection,String id) async {
    final u=auth.currentUser; if(u==null) throw Exception('कृपया पहले लॉगिन करें');
    final ref=db.collection('saved_posts').doc(u.uid).collection('items').doc('${collection}_$id');
    final snap=await ref.get(); if(snap.exists) await ref.delete(); else await ref.set({'collection':collection,'documentId':id,'createdAt':FieldValue.serverTimestamp()});
  }
  Future<void> recordShare(String collection,String id) async { final u=auth.currentUser; if(u==null)return; try { await db.collection('shares').add({'collection':collection,'documentId':id,'userUid':u.uid,'createdAt':FieldValue.serverTimestamp()}); await db.collection(collection).doc(id).update({'sharesCount':FieldValue.increment(1)}); } catch (_) {} }
  Future<bool> isLiked(String collection,String id) async { final u=auth.currentUser; if(u==null)return false; return (await db.collection('likes').doc('${collection}_$id').collection('users').doc(u.uid).get()).exists; }
  Future<bool> isSaved(String collection,String id) async { final u=auth.currentUser; if(u==null)return false; return (await db.collection('saved_posts').doc(u.uid).collection('items').doc('${collection}_$id').get()).exists; }
  Future<void> markNotificationRead(String id) async { await db.collection('notifications').doc(id).update({'read':true,'readAt':FieldValue.serverTimestamp()}); }
  Future<void> deleteComment(String id) async {
    final u=auth.currentUser; if(u==null)return;
    final ref=db.collection('comments').doc(id); final snap=await ref.get(); if(!snap.exists)return;
    final d=snap.data()!; if(d['authorUid']!=u.uid && !await isAdmin()) throw Exception('Permission denied');
    final contentRef=db.collection('${d['collection']}').doc('${d['documentId']}');
    await db.runTransaction((tx) async {
      final content=await tx.get(contentRef);
      tx.delete(ref);
      if(content.exists){ final current=((content.data()?['commentsCount'] ?? 0) as num).toInt(); tx.update(contentRef, {'commentsCount': current>0 ? current-1 : 0}); }
    });
  }

  Stream<QuerySnapshot<Map<String,dynamic>>> savedItems() { final u=auth.currentUser; if(u==null)return const Stream.empty(); return db.collection('saved_posts').doc(u.uid).collection('items').orderBy('createdAt',descending:true).snapshots(); }
  Stream<QuerySnapshot<Map<String,dynamic>>> myComplaints() { final u=auth.currentUser; if(u==null)return const Stream.empty(); return db.collection('complaints').where('userUid',isEqualTo:u.uid).orderBy('createdAt',descending:true).snapshots(); }
  Future<void> updateProfile(String name,String phone) async { final u=auth.currentUser; if(u==null)throw Exception('Login required'); await db.collection('users').doc(u.uid).update({'name':name.trim(),'phone':phone.trim(),'updatedAt':FieldValue.serverTimestamp()}); }

  Future<void> saveFcmToken() async {
    final u=auth.currentUser; if(u==null)return;
    try{await messaging.requestPermission(alert:true,badge:true,sound:true); final token=await messaging.getToken(); if(token!=null) await db.collection('users').doc(u.uid).collection('devices').doc(token).set({'token':token,'updatedAt':FieldValue.serverTimestamp(),'platform':Platform.operatingSystem}); messaging.onTokenRefresh.listen((t)=>db.collection('users').doc(u.uid).collection('devices').doc(t).set({'token':t,'updatedAt':FieldValue.serverTimestamp(),'platform':Platform.operatingSystem}));}catch(_){ }
  }
}
