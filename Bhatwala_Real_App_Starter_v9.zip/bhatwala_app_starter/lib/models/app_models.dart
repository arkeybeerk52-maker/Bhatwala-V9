enum UserRole { user, admin }
enum ModerationStatus { pending, approved, rejected, hidden }

class AppUser {
  final String uid;
  final String userId;
  final String name;
  final String? photoUrl;
  final String? phone;
  final String? email;
  final UserRole role;
  final bool blocked;

  const AppUser({
    required this.uid,
    required this.userId,
    required this.name,
    this.photoUrl,
    this.phone,
    this.email,
    this.role = UserRole.user,
    this.blocked = false,
  });

  Map<String, dynamic> toMap() => {
    'uid': uid,
    'userId': userId,
    'name': name,
    'photoUrl': photoUrl,
    'phone': phone,
    'email': email,
    'role': role.name,
    'blocked': blocked,
  };
}

class CommunityPost {
  final String id;
  final String title;
  final String description;
  final String authorUid;
  final String authorName;
  final String authorUserId;
  final String category;
  final List<String> mediaUrls;
  final ModerationStatus status;
  final DateTime createdAt;

  const CommunityPost({
    required this.id,
    required this.title,
    required this.description,
    required this.authorUid,
    required this.authorName,
    required this.authorUserId,
    required this.category,
    required this.mediaUrls,
    required this.status,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
    'title': title,
    'description': description,
    'authorUid': authorUid,
    'authorName': authorName,
    'authorUserId': authorUserId,
    'category': category,
    'mediaUrls': mediaUrls,
    'status': status.name,
    'createdAt': createdAt,
  };
}
