# Bhatwala release checklist

1. Configure Firebase project and add Flutter/Android app.
2. Generate `firebase_options.dart` (FlutterFire) and Android `google-services.json`.
3. Enable Email/Password Authentication.
4. Deploy `firestore.rules`, `firestore.indexes.json`, `storage.rules`.
5. Install/deploy `functions/` with Firebase CLI.
6. Test registration/login/password reset/profile/photo.
7. Test posts, media, business/jobs/events/news/farmer/place submission + admin moderation.
8. Test like/comment/save/share/report/search/notifications/emergency call/maps.
9. Verify blocked users and private complaints.
10. Build release APK and AAB; remove all builder/debug branding.
