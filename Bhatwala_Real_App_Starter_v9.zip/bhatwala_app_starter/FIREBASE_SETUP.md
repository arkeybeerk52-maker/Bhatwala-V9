# Firebase setup checklist

1. Create a Firebase project named Bhatwala.
2. Register the Android package/application ID chosen by the builder.
3. Add the Android Firebase config file.
4. Enable Authentication provider(s).
5. Create Firestore database.
6. Create Storage bucket if media uploads are required.
7. Deploy `firestore.rules`, `storage.rules`, and indexes.
8. Create/verify the admin account `raajchoudhary.rk52@gmail.com`.
9. Never put the admin password in source code or the prompt.
10. Test with two normal accounts and the admin account.

IMPORTANT:
The starter code intentionally does not contain Firebase secrets/config files.

## One-command project wiring

1. Install FlutterFire CLI and Firebase CLI on the build machine.
2. Run `flutterfire configure` and select the Bhatwala Firebase project.
3. Deploy backend with `firebase deploy --only firestore,storage,functions`.
4. Enable Email/Password Authentication, Firestore, Storage and Cloud Messaging.
5. Create the admin account `raajchoudhary.rk52@gmail.com` in Firebase Authentication, then set its Firestore `role` to `admin`.
6. Build with `flutter build apk --release` or `flutter build appbundle --release`.

No Firebase secret or admin password belongs in source control.
